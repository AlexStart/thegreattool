package com.zhytnik;

public class AppApplication {

	public static void main(String[] args) {
		System.out.println("Gradle app");
	}
}

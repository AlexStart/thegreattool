package com.zhytnik;

import org.junit.Test;

public class AppApplicationTest {

	@Test
	public void runs() {
	}

}

package com.zhytnik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppCheckerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppCheckerApplication.class, args);
	}
}
